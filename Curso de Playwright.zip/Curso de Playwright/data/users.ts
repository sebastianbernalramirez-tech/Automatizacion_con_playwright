/**
 * DATOS DE PRUEBA.
 * Se guardan aparte de los tests para no repetir usuarios y contraseñas en cada spec:
 * si una credencial cambia, se corrige solo aquí.
 */

/**
 * `interface` define la FORMA que debe tener un usuario: dos textos obligatorios.
 * La usa LoginPage.login(user: User) para saber qué datos recibe.
 */
export interface User {
  username: string;
  password: string;
}

// Usuario público del sitio de práctica https://opensource-demo.orangehrmlive.com
// (las credenciales aparecen en la propia pantalla de login del demo).
export const users = {
  // Usuario válido: con él el login funciona.
  admin: { username: 'Admin', password: 'admin123' },
  // Usuario que no existe: sirve para probar el mensaje de error.
  invalid: { username: 'usuario_invalido', password: 'clave_invalida' },

  // `satisfies Record<string, User>` le pide a TypeScript que compruebe que
  // cada elemento cumple la interfaz User (si falta `password`, marca error),
  // pero conservando los nombres exactos para que el editor autocomplete
  // `users.admin` y `users.invalid`.
} satisfies Record<string, User>;
