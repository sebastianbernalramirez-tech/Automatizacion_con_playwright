// `test` y `expect` del fixture propio (el que conoce los Page Objects).
import { test, expect } from '../fixtures/pages.fixture';
// Usuarios de prueba. Vienen de data/users.ts.
import { users } from '../data/users';

test.describe('Navegación', () => {
  // Estos tests necesitan empezar con la sesión iniciada,
  // así que el login se hace antes de cada uno.
  test.beforeEach(async ({ loginPage, dashboardPage }) => {
    await loginPage.goto();
    await loginPage.login(users.admin);
    // Se espera el Dashboard para asegurar que el login terminó antes de seguir.
    await dashboardPage.expectLoaded();
  });

  test('navega al módulo PIM desde el menú lateral', async ({ dashboardPage, pimPage }) => {
    // sideMenu viene de AppPage; navigateTo() está en el componente SideMenu.
    // 'PIM' debe ser uno de los valores del tipo MenuOption.
    await dashboardPage.sideMenu.navigateTo('PIM');

    // A partir de aquí la pantalla es otra, así que se usa su Page Object: pimPage.
    // (dashboardPage y pimPage comparten la misma pestaña del navegador.)
    await pimPage.expectLoaded();
    await expect(pimPage.topBar.title).toHaveText('PIM');
    // addButton es un locator propio de PimPage.
    await expect(pimPage.addButton).toBeVisible();
  });
});
