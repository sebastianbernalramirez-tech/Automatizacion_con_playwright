// IMPORTANTE: `test` y `expect` se importan del fixture propio, NO de '@playwright/test'.
// Solo este `test` conoce los fixtures loginPage, dashboardPage y pimPage.
import { test, expect } from '../fixtures/pages.fixture';
// Usuarios de prueba. Vienen de data/users.ts.
import { users } from '../data/users';

/**
 * Los archivos *.spec.ts dentro de /tests son los que Playwright ejecuta
 * (la carpeta se define en `testDir` de playwright.config.ts).
 *
 * Fíjate que aquí NO hay selectores ni detalles del HTML: el test solo dice
 * QUÉ se hace; el CÓMO está en los Page Objects. Ese es el objetivo del patrón POM.
 */

// `test.describe` agrupa tests relacionados bajo un mismo nombre en el reporte.
test.describe('Login', () => {
  // `beforeEach` se ejecuta ANTES de cada test del grupo.
  // Entre llaves se piden los fixtures que se necesitan: aquí solo loginPage.
  test.beforeEach(async ({ loginPage }) => {
    // goto() está definido en BasePage y usa el `path` de LoginPage.
    await loginPage.goto();
  });

  // Cada `test` recibe una pestaña nueva y aislada: no comparten sesión entre sí.
  test('inicia sesión con credenciales válidas', async ({ loginPage, dashboardPage }) => {
    // login() está en LoginPage; users.admin viene de data/users.ts.
    await loginPage.login(users.admin);

    // expectLoaded() está en BasePage: verifica que la URL sea la del Dashboard.
    await dashboardPage.expectLoaded();
    // topBar viene de AppPage; `title` es un locator definido en TopBar.
    await expect(dashboardPage.topBar.title).toHaveText('Dashboard');
  });

  test('muestra error con credenciales inválidas', async ({ loginPage }) => {
    await loginPage.login(users.invalid);

    // expectError() está en LoginPage: revisa el texto de la alerta.
    await loginPage.expectError('Invalid credentials');
  });

  test('exige usuario y contraseña', async ({ loginPage }) => {
    // Se pulsa Login sin llenar nada, usando el locator directamente.
    await loginPage.loginButton.click();

    // Con un arreglo, toHaveText comprueba que haya exactamente 2 elementos
    // y que cada uno tenga ese texto (uno por campo vacío).
    await expect(loginPage.requiredMessages).toHaveText(['Required', 'Required']);
  });

  test('cierra sesión', async ({ loginPage, dashboardPage }) => {
    await loginPage.login(users.admin);
    await dashboardPage.expectLoaded();

    // logout() está en el componente TopBar.
    await dashboardPage.topBar.logout();

    // Al cerrar sesión la aplicación vuelve a la pantalla de login.
    await loginPage.expectLoaded();
  });
});
