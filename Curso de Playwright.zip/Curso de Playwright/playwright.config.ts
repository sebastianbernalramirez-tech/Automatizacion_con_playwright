// `defineConfig`: función que valida la configuración y da autocompletado.
// `devices`: catálogo de navegadores y dispositivos predefinidos (tamaño de pantalla, user agent...).
// Ambos vienen del paquete @playwright/test.
import { defineConfig, devices } from '@playwright/test';

/**
 * CONFIGURACIÓN GENERAL DE PLAYWRIGHT.
 * Playwright lee este archivo automáticamente cada vez que se ejecuta `npx playwright test`.
 * Lo generó `npm init playwright`; solo se le agregó el baseURL.
 * Documentación: https://playwright.dev/docs/test-configuration
 */

/**
 * (Opcional) Leer variables de entorno desde un archivo .env.
 * Está comentado porque requiere instalar el paquete dotenv.
 * https://github.com/motdotla/dotenv
 */
// import dotenv from 'dotenv';
// import path from 'path';
// dotenv.config({ path: path.resolve(__dirname, '.env') });

export default defineConfig({
  // Carpeta donde Playwright busca los archivos *.spec.ts.
  testDir: './tests',

  // Ejecuta en paralelo también los tests de un mismo archivo.
  fullyParallel: true,

  // `process.env.CI` es una variable de entorno que existe cuando los tests corren
  // en un servidor de integración continua (por ejemplo GitHub Actions).
  // `!!` convierte el valor en true/false.
  // En CI, falla si alguien dejó un `test.only` olvidado en el código.
  forbidOnly: !!process.env.CI,

  // Reintentos si un test falla: 2 en CI, 0 en tu máquina.
  // (condición ? valorSiVerdadero : valorSiFalso)
  retries: process.env.CI ? 2 : 0,

  // Cantidad de tests simultáneos: 1 en CI; en local `undefined` deja que
  // Playwright lo decida según los núcleos del procesador.
  workers: process.env.CI ? 1 : undefined,

  // Formato del reporte. 'html' genera la carpeta playwright-report/
  // (se abre con `npm run report`).
  reporter: 'html',

  // Opciones compartidas por todos los tests y todos los navegadores.
  use: {
    // URL base de la aplicación. Se une con el `path` de cada Page Object:
    //   page.goto('/web/index.php/auth/login')
    //   -> https://opensource-demo.orangehrmlive.com/web/index.php/auth/login
    //
    // `??` significa "si lo de la izquierda no existe, usa lo de la derecha":
    // si se define la variable de entorno BASE_URL se usa esa; si no, la URL fija.
    // Sirve para apuntar a otro ambiente sin tocar el código:
    //   $env:BASE_URL = 'https://otro-ambiente.com'; npx playwright test
    baseURL: process.env.BASE_URL ?? 'https://opensource-demo.orangehrmlive.com',

    // Graba una "traza" (paso a paso con capturas) solo cuando un test se reintenta.
    // https://playwright.dev/docs/trace-viewer
    trace: 'on-first-retry',
  },

  // Cada "proyecto" es un navegador: todos los tests se ejecutan una vez por proyecto.
  // Para correr solo uno: npx playwright test --project=chromium
  projects: [
    {
      name: 'chromium',
      // `...` copia dentro de `use` todas las opciones del dispositivo predefinido.
      use: { ...devices['Desktop Chrome'] },
    },

    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },

    {
      name: 'webkit', // el motor de Safari
      use: { ...devices['Desktop Safari'] },
    },

    /* Pruebas en pantallas de celular (descomentar para activarlas). */
    // {
    //   name: 'Mobile Chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
    // {
    //   name: 'Mobile Safari',
    //   use: { ...devices['iPhone 12'] },
    // },

    /* Pruebas en los navegadores instalados en el equipo (Edge, Chrome). */
    // {
    //   name: 'Microsoft Edge',
    //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
    // },
    // {
    //   name: 'Google Chrome',
    //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    // },
  ],

  /* Levantar un servidor local antes de los tests (no aplica: la aplicación está en internet). */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://localhost:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});
