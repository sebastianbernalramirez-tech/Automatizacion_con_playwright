// `test` es la función original de Playwright para declarar tests.
// Se importa con otro nombre (`base`) porque más abajo se crea
// una versión propia que también se llamará `test`.
import { test as base } from '@playwright/test';
// Los Page Objects, importados desde el barril pages/index.ts.
import { DashboardPage, LoginPage, PimPage } from '../pages';

/**
 * ¿QUÉ ES UN FIXTURE?
 * Es algo que Playwright prepara y le entrega al test ya listo para usar.
 * Playwright trae fixtures propios, como `page` (una pestaña nueva por test).
 * Aquí se agregan fixtures PROPIOS: uno por cada Page Object.
 *
 * Sin fixtures, cada test tendría que empezar así:
 *   const loginPage = new LoginPage(page);
 *   const dashboardPage = new DashboardPage(page);
 *
 * Con fixtures basta con pedirlos entre llaves:
 *   test('...', async ({ loginPage, dashboardPage }) => { ... });
 */

// Tipo que declara qué fixtures nuevos existen y de qué clase es cada uno.
// Gracias a esto el editor autocompleta `loginPage.` dentro de los tests.
type PageFixtures = {
  loginPage: LoginPage;
  dashboardPage: DashboardPage;
  pimPage: PimPage;
};

/**
 * `base.extend` crea una copia del `test` de Playwright con los fixtures añadidos.
 * `<PageFixtures>` le indica a TypeScript cuáles son.
 */
export const test = base.extend<PageFixtures>({
  // Cada fixture es una función con dos parámetros:
  //   { page } -> otros fixtures que necesita (aquí, la pestaña que crea Playwright)
  //   use      -> función a la que se le entrega el valor que recibirá el test
  loginPage: async ({ page }, use) => {
    // Aquí es donde nace el Page Object y recibe la `page`:
    // esta `page` es la que llega al constructor de BasePage.
    await use(new LoginPage(page));
    // Lo que se escriba después de `use` se ejecuta al TERMINAR el test (limpieza).
  },
  dashboardPage: async ({ page }, use) => {
    await use(new DashboardPage(page));
  },
  pimPage: async ({ page }, use) => {
    await use(new PimPage(page));
  },
  // Dentro de un mismo test todos reciben la MISMA `page`, por eso
  // loginPage y dashboardPage trabajan sobre la misma pestaña.
  // Un fixture solo se crea si el test lo pide.
  //
  // AL CREAR UNA PÁGINA NUEVA, hay que agregarla en PageFixtures y aquí.
});

// Se reexporta `expect` para que los specs importen todo desde este archivo:
//   import { test, expect } from '../fixtures/pages.fixture';
export { expect } from '@playwright/test';
