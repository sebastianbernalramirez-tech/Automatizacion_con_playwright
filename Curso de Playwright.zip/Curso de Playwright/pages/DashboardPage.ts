// Clase padre de las páginas con sesión iniciada. Viene de pages/AppPage.ts.
import { AppPage } from './AppPage';

/**
 * Page Object del Dashboard: la pantalla a la que se llega después del login.
 * URL: https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index
 *
 * La clase se ve casi vacía porque TODO lo hereda:
 *   - de BasePage: goto() y expectLoaded()
 *   - de AppPage:  sideMenu y topBar
 *
 * No necesita constructor propio: al no escribirlo, se usa el de AppPage.
 * Cuando haga falta probar los widgets del Dashboard, sus locators se agregan aquí.
 */
export class DashboardPage extends AppPage {
  // Lo único obligatorio: la ruta de esta página (lo exige BasePage con `abstract`).
  protected readonly path = '/web/index.php/dashboard/index';
}
