// Tipos de Playwright (solo tipos, por eso `import type`).
import type { Locator, Page } from '@playwright/test';

/**
 * Tipo con las opciones válidas del menú lateral.
 *
 * El símbolo `|` significa "o": un MenuOption solo puede ser uno de estos textos.
 * Ventaja: si en un test se escribe navigateTo('PIN') por error,
 * TypeScript lo marca antes de ejecutar y el editor autocompleta las opciones.
 *
 * Los textos son exactamente los que se ven en el menú de OrangeHRM.
 */
export type MenuOption =
  | 'Admin'
  | 'PIM'
  | 'Leave'
  | 'Time'
  | 'Recruitment'
  | 'My Info'
  | 'Performance'
  | 'Dashboard'
  | 'Directory'
  | 'Buzz';

/**
 * COMPONENTE: menú lateral.
 *
 * Un componente es como un Page Object, pero de UN TROZO de pantalla que se repite
 * en varias páginas. No hereda de BasePage porque no es una página: no tiene URL propia.
 * Lo crea AppPage y queda disponible como `cualquierPagina.sideMenu`.
 */
export class SideMenu {
  // Locator del contenedor del menú. Los enlaces se buscan DENTRO de él.
  readonly root: Locator;

  // Recibe la `page` que le pasa AppPage (`new SideMenu(page)`).
  constructor(page: Page) {
    // En el HTML el menú es: <nav aria-label="Sidepanel">
    // El rol de <nav> es 'navigation' y su nombre sale de aria-label.
    this.root = page.getByRole('navigation', { name: 'Sidepanel' });
  }

  /**
   * Devuelve el locator de una opción del menú.
   *
   * Se busca a partir de `this.root` (no de `page`) para encontrar solo
   * los enlaces que están dentro del menú lateral.
   *
   * `{ name, exact: true }`: `name` es la forma corta de `name: name`,
   * y `exact: true` exige que el texto coincida completo.
   */
  option(name: MenuOption): Locator {
    return this.root.getByRole('link', { name, exact: true });
  }

  /** ACCIÓN: hace clic en una opción del menú para ir a ese módulo. */
  async navigateTo(name: MenuOption): Promise<void> {
    await this.option(name).click();
  }
}
