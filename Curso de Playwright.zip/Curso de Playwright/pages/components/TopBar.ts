// Tipos de Playwright (solo tipos, por eso `import type`).
import type { Locator, Page } from '@playwright/test';

/**
 * COMPONENTE: barra superior.
 * Muestra el título del módulo actual y el menú del usuario (donde está Logout).
 *
 * Igual que SideMenu, lo crea AppPage y queda disponible como `cualquierPagina.topBar`.
 */
export class TopBar {
  readonly title: Locator;
  readonly userMenu: Locator;
  readonly logoutOption: Locator;

  // Recibe la `page` que le pasa AppPage (`new TopBar(page)`).
  constructor(page: Page) {
    // Título del módulo ("Dashboard", "PIM"...).
    // Dos pasos encadenados: primero se ubica el contenedor por su clase CSS
    // y DENTRO de él se busca el encabezado (<h6>, cuyo rol es 'heading').
    // Así no se confunde con otros encabezados de la página.
    this.title = page.locator('.oxd-topbar-header-breadcrumb').getByRole('heading');

    // Pestaña con la foto y el nombre del usuario, arriba a la derecha.
    // No tiene rol ni texto fijo (el nombre cambia), por eso se usa su clase CSS.
    this.userMenu = page.locator('.oxd-userdropdown-tab');

    // Opción "Logout" del menú desplegable: <a role="menuitem">Logout</a>
    // Solo es visible después de abrir el menú del usuario.
    this.logoutOption = page.getByRole('menuitem', { name: 'Logout' });
  }

  /** ACCIÓN: cerrar sesión (abrir el menú del usuario y elegir Logout). */
  async logout(): Promise<void> {
    await this.userMenu.click();
    // No hace falta esperar a que se abra el menú: `click` espera solo
    // hasta que el elemento sea visible y se pueda pulsar.
    await this.logoutOption.click();
  }
}
