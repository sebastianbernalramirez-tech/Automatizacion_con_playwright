// Tipo `Page` de Playwright (solo como tipo, por eso `import type`).
import type { Page } from '@playwright/test';
// Clase padre con goto() y expectLoaded(). Viene de pages/BasePage.ts.
import { BasePage } from './BasePage';
// Componentes que se repiten en varias pantallas. Vienen de pages/components/.
import { SideMenu } from './components/SideMenu';
import { TopBar } from './components/TopBar';

/**
 * AppPage: base de las páginas que se ven CON SESIÓN INICIADA.
 *
 * En OrangeHRM, después del login todas las pantallas (Dashboard, PIM, Admin...)
 * comparten el menú lateral y la barra superior. En vez de repetir esos locators
 * en cada página, se crean una sola vez como "componentes" y se exponen aquí.
 *
 * Cadena de herencia:
 *   BasePage  ->  AppPage  ->  DashboardPage / PimPage
 *   BasePage  ->  LoginPage   (el login no tiene menú, por eso no hereda de AppPage)
 *
 * También es `abstract`: no se usa directamente, solo se hereda.
 */
export abstract class AppPage extends BasePage {
  // `readonly` sin `protected` = públicas: los tests pueden usarlas así:
  //   dashboardPage.sideMenu.navigateTo('PIM')
  //   dashboardPage.topBar.logout()
  readonly sideMenu: SideMenu;
  readonly topBar: TopBar;

  constructor(page: Page) {
    // `super(page)` llama al constructor de la clase padre (BasePage),
    // que es quien guarda `this.page`. Siempre debe ir primero.
    super(page);

    // Se le pasa la misma `page` a cada componente para que busquen
    // sus elementos en la misma pestaña del navegador.
    this.sideMenu = new SideMenu(page);
    this.topBar = new TopBar(page);
  }
}
