/**
 * Archivo "barril" (barrel): reexporta todas las páginas desde un solo punto.
 *
 * Gracias a esto, en otros archivos se puede escribir UNA sola línea:
 *   import { LoginPage, DashboardPage } from '../pages';
 * en lugar de una por archivo:
 *   import { LoginPage } from '../pages/LoginPage';
 *   import { DashboardPage } from '../pages/DashboardPage';
 *
 * Cuando Node importa una carpeta ('../pages'), busca automáticamente su index.ts.
 *
 * AL CREAR UNA PÁGINA NUEVA, hay que agregarla aquí.
 */
export { BasePage } from './BasePage';
export { AppPage } from './AppPage';
export { LoginPage } from './LoginPage';
export { DashboardPage } from './DashboardPage';
export { PimPage } from './PimPage';
