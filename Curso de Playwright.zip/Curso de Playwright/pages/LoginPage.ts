// `expect`: aserciones. `Locator`: tipo de un elemento localizable. `Page`: tipo de la pestaña.
// Todo viene del paquete @playwright/test.
import { expect, type Locator, type Page } from '@playwright/test';
// Clase padre con goto() y expectLoaded(). Viene de pages/BasePage.ts.
import { BasePage } from './BasePage';
// Tipo que describe un usuario { username, password }. Viene de data/users.ts.
import type { User } from '../data/users';

/**
 * Page Object de la pantalla de login.
 * URL: https://opensource-demo.orangehrmlive.com/web/index.php/auth/login
 *
 * Hereda de BasePage (no de AppPage) porque en el login todavía
 * no existen el menú lateral ni la barra superior.
 */
export class LoginPage extends BasePage {
  // Valor de la propiedad `path` que BasePage obliga a definir.
  // Es la parte de la URL que va después del baseURL.
  protected readonly path = '/web/index.php/auth/login';

  // LOCATORS: cada uno describe CÓMO encontrar un elemento de la pantalla.
  // Un Locator no busca el elemento al crearlo; lo busca cada vez que se usa
  // (click, fill, expect...). Por eso se pueden declarar antes de abrir la página.
  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly errorAlert: Locator;
  readonly requiredMessages: Locator;

  constructor(page: Page) {
    // Llama al constructor de BasePage para guardar `this.page`.
    super(page);

    // getByPlaceholder: busca un input por su texto de ayuda.
    // En el HTML es: <input placeholder="Username">
    this.usernameInput = page.getByPlaceholder('Username');
    this.passwordInput = page.getByPlaceholder('Password');

    // getByRole: busca por rol de accesibilidad + nombre visible.
    // Es la forma recomendada por Playwright porque imita cómo el usuario ve la página.
    // En el HTML es: <button type="submit"> Login </button>
    this.loginButton = page.getByRole('button', { name: 'Login' });

    // El mensaje "Invalid credentials" aparece en un <div role="alert">.
    this.errorAlert = page.getByRole('alert');

    // Mensajes "Required" debajo de los campos vacíos.
    // No tienen rol ni texto único, así que se usa un selector CSS por clase.
    // (El punto inicial significa "clase": .oxd-input-field-error-message)
    this.requiredMessages = page.locator('.oxd-input-field-error-message');
  }

  /**
   * ACCIÓN: iniciar sesión.
   * Recibe un usuario (de data/users.ts) y hace los tres pasos del formulario.
   * Los tests llaman solo `loginPage.login(users.admin)` sin saber los detalles.
   */
  async login(user: User): Promise<void> {
    // fill: borra el campo y escribe el texto.
    await this.usernameInput.fill(user.username);
    await this.passwordInput.fill(user.password);
    await this.loginButton.click();
  }

  /**
   * VERIFICACIÓN: comprueba que la alerta de error contenga el mensaje esperado.
   * `string | RegExp` significa que acepta un texto o una expresión regular.
   */
  async expectError(message: string | RegExp): Promise<void> {
    await expect(this.errorAlert).toContainText(message);
  }
}
