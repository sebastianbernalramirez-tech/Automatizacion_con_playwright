// `expect` es la función de aserciones de Playwright (expect(algo).toHaveURL(...)).
// `Page` es el TIPO que representa una pestaña del navegador.
// La palabra `type` indica que `Page` se importa solo como tipo de TypeScript:
// sirve para el autocompletado y la validación, pero no existe al ejecutar.
// Ambos vienen del paquete @playwright/test (instalado en node_modules).
import { expect, type Page } from '@playwright/test';

/**
 * BasePage: la clase "padre" de todos los Page Objects.
 *
 * ¿Qué es el patrón POM (Page Object Model)?
 * Es crear UNA CLASE POR CADA PANTALLA de la aplicación. Cada clase guarda:
 *   - los locators (cómo encontrar los elementos de esa pantalla), y
 *   - las acciones (qué se puede hacer en esa pantalla).
 * Así los tests no repiten selectores: si la pantalla cambia, se corrige en un solo lugar.
 *
 * Aquí va lo que TODAS las páginas tienen en común (navegar y verificar la URL),
 * para no repetirlo en cada una.
 *
 * `abstract` significa que esta clase no se puede usar directamente
 * (no existe `new BasePage()`); solo sirve para que otras la hereden con `extends`.
 */
export abstract class BasePage {
  /**
   * Ruta de la página, relativa al `baseURL` definido en playwright.config.ts.
   *
   * - `abstract`: BasePage no le da valor; OBLIGA a cada página hija a definir el suyo.
   * - `protected`: solo se puede usar dentro de esta clase y de sus hijas (no desde los tests).
   * - `readonly`: una vez asignado no se puede cambiar.
   */
  protected abstract readonly path: string;

  /**
   * El constructor se ejecuta al hacer `new LoginPage(page)`.
   *
   * `protected readonly page: Page` es un atajo de TypeScript: declara la propiedad
   * `this.page` y le asigna el valor recibido, todo en una línea.
   *
   * ¿De dónde viene `page`? La crea Playwright para cada test (una pestaña nueva y limpia)
   * y llega hasta aquí desde fixtures/pages.fixture.ts.
   */
  constructor(protected readonly page: Page) {}

  /**
   * Abre la página en el navegador.
   *
   * `this.path` es la ruta de la página hija (por ejemplo '/web/index.php/auth/login').
   * Playwright la une con el baseURL del config:
   *   baseURL + path = https://opensource-demo.orangehrmlive.com/web/index.php/auth/login
   *
   * `async` / `await`: las acciones del navegador tardan, así que devuelven una Promesa.
   * `await` espera a que termine antes de pasar a la siguiente línea.
   * `Promise<void>` significa "función asíncrona que no devuelve ningún valor".
   */
  async goto(): Promise<void> {
    await this.page.goto(this.path);
  }

  /**
   * Verifica que el navegador esté en la URL de esta página.
   *
   * `toHaveURL` reintenta automáticamente hasta que se cumpla o se agote el tiempo
   * (5 segundos por defecto), por eso no hace falta poner esperas manuales.
   */
  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(this.path);
  }
}
