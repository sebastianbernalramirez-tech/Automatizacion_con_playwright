// Tipos de Playwright (solo tipos, por eso `import type`).
import type { Locator, Page } from '@playwright/test';
// Clase padre de las páginas con sesión iniciada. Viene de pages/AppPage.ts.
import { AppPage } from './AppPage';

/**
 * Page Object del módulo PIM (gestión de empleados).
 * URL: https://opensource-demo.orangehrmlive.com/web/index.php/pim/viewEmployeeList
 *
 * Hereda de AppPage, así que ya tiene sideMenu, topBar, goto() y expectLoaded().
 * Aquí solo se agrega lo que es PROPIO de esta pantalla.
 */
export class PimPage extends AppPage {
  protected readonly path = '/web/index.php/pim/viewEmployeeList';

  // Locators propios de la lista de empleados.
  readonly addButton: Locator;
  readonly searchButton: Locator;

  // Como esta clase tiene locators propios, necesita su constructor
  // para crearlos (a diferencia de DashboardPage, que no tiene ninguno).
  constructor(page: Page) {
    // Primero el constructor del padre (AppPage), que crea sideMenu y topBar.
    super(page);

    // Botones buscados por rol + texto visible:
    // <button> Add </button>  y  <button type="submit"> Search </button>
    this.addButton = page.getByRole('button', { name: 'Add' });
    this.searchButton = page.getByRole('button', { name: 'Search' });
  }
}
