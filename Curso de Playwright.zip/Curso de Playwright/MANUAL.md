# Manual de estudio: Playwright con Page Object Model (POM)

Este manual explica, paso a paso y en orden, cómo construir desde cero un proyecto como este para que puedas repetirlo con cualquier otra aplicación. Cada paso indica **qué hacer**, **por qué** y **cómo comprobar** que quedó bien.

El ejemplo usa el sitio de práctica OrangeHRM (`https://opensource-demo.orangehrmlive.com`), el mismo de este proyecto, así que puedes comparar cada paso con los archivos reales.

---

## Índice

1. [Qué vas a construir](#1-qué-vas-a-construir)
2. [Requisitos previos](#2-requisitos-previos)
3. [Paso 1: crear el proyecto](#3-paso-1-crear-el-proyecto)
4. [Paso 2: explorar la aplicación antes de programar](#4-paso-2-explorar-la-aplicación-antes-de-programar)
5. [Paso 3: configurar la URL base](#5-paso-3-configurar-la-url-base)
6. [Paso 4: crear las carpetas](#6-paso-4-crear-las-carpetas)
7. [Paso 5: datos de prueba](#7-paso-5-datos-de-prueba)
8. [Paso 6: la clase BasePage](#8-paso-6-la-clase-basepage)
9. [Paso 7: tu primer Page Object](#9-paso-7-tu-primer-page-object)
10. [Paso 8: el fixture](#10-paso-8-el-fixture)
11. [Paso 9: tu primer test](#11-paso-9-tu-primer-test)
12. [Paso 10: componentes compartidos](#12-paso-10-componentes-compartidos)
13. [Paso 11: más páginas](#13-paso-11-más-páginas)
14. [Paso 12: scripts de ejecución](#14-paso-12-scripts-de-ejecución)
15. [Cómo elegir un buen locator](#15-cómo-elegir-un-buen-locator)
16. [Reglas del patrón POM](#16-reglas-del-patrón-pom)
17. [Receta: agregar una página nueva](#17-receta-agregar-una-página-nueva)
18. [Comandos útiles](#18-comandos-útiles)
19. [Errores frecuentes](#19-errores-frecuentes)
20. [Ejercicios](#20-ejercicios)
21. [Glosario](#21-glosario)

---

## 1. Qué vas a construir

**Page Object Model (POM)** es una forma de organizar las pruebas: se crea **una clase por cada pantalla** de la aplicación. Cada clase guarda dos cosas:

- **Locators**: cómo encontrar los elementos de esa pantalla.
- **Acciones**: qué se puede hacer en esa pantalla (`login()`, `logout()`...).

Los tests usan esas clases y nunca escriben selectores. Compara:

```ts
// SIN POM: el test conoce todos los detalles del HTML
await page.goto('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
await page.getByPlaceholder('Username').fill('Admin');
await page.getByPlaceholder('Password').fill('admin123');
await page.getByRole('button', { name: 'Login' }).click();

// CON POM: el test solo dice qué se hace
await loginPage.goto();
await loginPage.login(users.admin);
```

Si mañana cambia el botón de Login, sin POM hay que corregir todos los tests; con POM se corrige una sola línea en `LoginPage.ts`.

### Estructura final

```
mi-proyecto/
├── playwright.config.ts      configuración (URL base, navegadores)
├── package.json              dependencias y scripts
├── tsconfig.json             reglas de TypeScript
├── data/
│   └── users.ts              datos de prueba
├── pages/
│   ├── BasePage.ts           lo común a TODAS las páginas
│   ├── AppPage.ts            lo común a las páginas con sesión iniciada
│   ├── LoginPage.ts          una clase por pantalla
│   ├── DashboardPage.ts
│   ├── PimPage.ts
│   ├── index.ts              reexporta todas las páginas
│   └── components/
│       ├── SideMenu.ts       trozos de pantalla que se repiten
│       └── TopBar.ts
├── fixtures/
│   └── pages.fixture.ts      crea los Page Objects y los entrega a los tests
└── tests/
    ├── login.spec.ts         los tests
    └── navigation.spec.ts
```

### Cómo se conectan las piezas

```
playwright.config.ts ──► baseURL
        +
pages/LoginPage.ts   ──► path  ──►  URL completa de la pantalla

@playwright/test ──► page (una pestaña nueva por cada test)
        │
fixtures/pages.fixture.ts ──► new LoginPage(page)
        │
tests/login.spec.ts ──► async ({ loginPage }) => { ... }
```

---

## 2. Requisitos previos

| Necesitas | Para qué | Cómo comprobarlo |
|---|---|---|
| Node.js (versión LTS) | Ejecutar Playwright | `node -v` |
| npm (viene con Node) | Instalar paquetes | `npm -v` |
| Visual Studio Code | Editar el código | — |
| Extensión "Playwright Test for VSCode" (opcional) | Ejecutar tests desde el editor | — |

Conocimientos mínimos de TypeScript que conviene repasar: variables, funciones, `async/await`, clases, herencia (`extends`) e `import/export`.

---

## 3. Paso 1: crear el proyecto

**Aquí empieza todo.** En una carpeta vacía, abre la terminal y ejecuta:

```powershell
npm init playwright@latest
```

Responde así a las preguntas:

| Pregunta | Respuesta |
|---|---|
| TypeScript o JavaScript | **TypeScript** |
| Carpeta de los tests | **tests** |
| Agregar workflow de GitHub Actions | A tu gusto (no afecta el aprendizaje) |
| Instalar los navegadores de Playwright | **true** |

Esto crea `playwright.config.ts`, `package.json`, la carpeta `tests/` con `example.spec.ts` y descarga los navegadores.

**Comprobación:**

```powershell
npx playwright test
npx playwright show-report
```

Deben pasar los tests de ejemplo y abrirse el reporte. Si esto funciona, la instalación está bien.

---

## 4. Paso 2: explorar la aplicación antes de programar

No empieces escribiendo código. Primero recorre la aplicación a mano y anota:

1. **Qué pantallas hay** → cada una será una clase.
2. **Qué URL tiene cada una** → será su `path`.
3. **Qué se puede hacer en cada una** → serán sus métodos.
4. **Qué partes se repiten** entre pantallas (menús, cabeceras) → serán componentes.

Para OrangeHRM el resultado es:

| Pantalla | Ruta | Acciones | Clase |
|---|---|---|---|
| Login | `/web/index.php/auth/login` | iniciar sesión, ver error | `LoginPage` |
| Dashboard | `/web/index.php/dashboard/index` | — | `DashboardPage` |
| PIM | `/web/index.php/pim/viewEmployeeList` | agregar, buscar | `PimPage` |

Partes repetidas: el **menú lateral** y la **barra superior** aparecen en todas las pantallas con sesión iniciada → `SideMenu` y `TopBar`.

### Herramienta para descubrir locators

```powershell
npx playwright codegen https://opensource-demo.orangehrmlive.com
```

Abre el navegador y, al hacer clic en los elementos, te muestra el locator que Playwright recomienda. Úsalo para **copiar locators**, no para copiar tests completos: el código que genera no sigue el patrón POM.

---

## 5. Paso 3: configurar la URL base

En `playwright.config.ts`, dentro de `use`, define el `baseURL`:

```ts
use: {
  baseURL: process.env.BASE_URL ?? 'https://opensource-demo.orangehrmlive.com',
  trace: 'on-first-retry',
},
```

- Pon **solo el dominio**, sin la ruta. La ruta la pone cada Page Object en su `path`.
- `process.env.BASE_URL ?? '...'` permite cambiar de ambiente sin tocar el código:

```powershell
$env:BASE_URL = 'https://otro-ambiente.com'; npx playwright test
```

**Por qué:** si la dirección de la aplicación cambia, se corrige en un único lugar.

---

## 6. Paso 4: crear las carpetas

```powershell
New-Item -ItemType Directory pages, pages\components, fixtures, data
```

Opcionalmente crea `tsconfig.json` en la raíz para activar el modo estricto, que detecta más errores mientras escribes:

```json
{
  "compilerOptions": {
    "target": "ESNext",
    "module": "commonjs",
    "moduleResolution": "node",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "noEmit": true,
    "types": ["node"]
  },
  "include": ["pages", "fixtures", "data", "tests", "playwright.config.ts"]
}
```

---

## 7. Paso 5: datos de prueba

Archivo `data/users.ts`:

```ts
export interface User {
  username: string;
  password: string;
}

export const users = {
  admin: { username: 'Admin', password: 'admin123' },
  invalid: { username: 'usuario_invalido', password: 'clave_invalida' },
} satisfies Record<string, User>;
```

**Por qué va primero:** el Page Object del login necesita el tipo `User`.

**Importante:** estas credenciales son públicas porque el sitio es de práctica. En un proyecto real las contraseñas **no se escriben en el código**: se leen de variables de entorno (`process.env.PASSWORD`).

---

## 8. Paso 6: la clase BasePage

Archivo `pages/BasePage.ts`. Contiene lo que **todas** las páginas comparten:

```ts
import { expect, type Page } from '@playwright/test';

export abstract class BasePage {
  protected abstract readonly path: string;

  constructor(protected readonly page: Page) {}

  async goto(): Promise<void> {
    await this.page.goto(this.path);
  }

  async expectLoaded(): Promise<void> {
    await expect(this.page).toHaveURL(this.path);
  }
}
```

Claves para entenderla:

| Palabra | Significado |
|---|---|
| `abstract class` | No se puede usar directamente; solo se hereda |
| `abstract path` | Obliga a cada página hija a definir su ruta |
| `protected` | Visible en la clase y sus hijas, pero no desde los tests |
| `readonly` | No se puede reasignar |
| `constructor(protected readonly page: Page)` | Declara `this.page` y le asigna el valor en una línea |

---

## 9. Paso 7: tu primer Page Object

Empieza siempre por la pantalla de entrada de la aplicación. Archivo `pages/LoginPage.ts`:

```ts
import { expect, type Locator, type Page } from '@playwright/test';
import { BasePage } from './BasePage';
import type { User } from '../data/users';

export class LoginPage extends BasePage {
  protected readonly path = '/web/index.php/auth/login';

  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly errorAlert: Locator;

  constructor(page: Page) {
    super(page);
    this.usernameInput = page.getByPlaceholder('Username');
    this.passwordInput = page.getByPlaceholder('Password');
    this.loginButton = page.getByRole('button', { name: 'Login' });
    this.errorAlert = page.getByRole('alert');
  }

  async login(user: User): Promise<void> {
    await this.usernameInput.fill(user.username);
    await this.passwordInput.fill(user.password);
    await this.loginButton.click();
  }

  async expectError(message: string | RegExp): Promise<void> {
    await expect(this.errorAlert).toContainText(message);
  }
}
```

Todo Page Object tiene las mismas **cuatro partes**, siempre en este orden:

1. **`path`**: la ruta de la pantalla.
2. **Locators** declarados como propiedades `readonly`.
3. **Constructor**: llama a `super(page)` y asigna cada locator.
4. **Métodos**: acciones (`login`) y verificaciones (`expectError`).

Un locator no busca el elemento al crearse; lo busca cada vez que se usa. Por eso se pueden declarar en el constructor, antes de abrir la página.

---

## 10. Paso 8: el fixture

Archivo `fixtures/pages.fixture.ts`. Un **fixture** es algo que Playwright prepara y entrega al test ya listo. Aquí se crea uno por cada Page Object:

```ts
import { test as base } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';

type PageFixtures = {
  loginPage: LoginPage;
};

export const test = base.extend<PageFixtures>({
  loginPage: async ({ page }, use) => {
    await use(new LoginPage(page));
  },
});

export { expect } from '@playwright/test';
```

**Por qué:** sin el fixture, cada test tendría que empezar con `const loginPage = new LoginPage(page);`. Con él, basta pedirlo entre llaves.

---

## 11. Paso 9: tu primer test

Archivo `tests/login.spec.ts`:

```ts
import { test } from '../fixtures/pages.fixture';
import { users } from '../data/users';

test.describe('Login', () => {
  test.beforeEach(async ({ loginPage }) => {
    await loginPage.goto();
  });

  test('muestra error con credenciales inválidas', async ({ loginPage }) => {
    await loginPage.login(users.invalid);

    await loginPage.expectError('Invalid credentials');
  });
});
```

**Regla de oro:** `test` y `expect` se importan de **tu fixture**, no de `@playwright/test`. Solo tu `test` conoce `loginPage`.

**Comprobación:**

```powershell
npx playwright test login --project=chromium --headed
```

**No sigas hasta que este test pase.** Avanza siempre así: una página, un test, ejecutar, y solo entonces la siguiente.

---

## 12. Paso 10: componentes compartidos

Cuando un trozo de pantalla se repite en varias páginas, se crea un **componente**: una clase como un Page Object, pero sin URL y sin heredar de `BasePage`.

`pages/components/SideMenu.ts`:

```ts
import type { Locator, Page } from '@playwright/test';

export type MenuOption = 'Admin' | 'PIM' | 'Leave' | 'Dashboard';

export class SideMenu {
  readonly root: Locator;

  constructor(page: Page) {
    this.root = page.getByRole('navigation', { name: 'Sidepanel' });
  }

  option(name: MenuOption): Locator {
    return this.root.getByRole('link', { name, exact: true });
  }

  async navigateTo(name: MenuOption): Promise<void> {
    await this.option(name).click();
  }
}
```

`pages/components/TopBar.ts` sigue la misma idea (título del módulo y `logout()`).

Luego se crea una clase intermedia, `pages/AppPage.ts`, que entrega esos componentes a todas las páginas con sesión iniciada:

```ts
import type { Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { SideMenu } from './components/SideMenu';
import { TopBar } from './components/TopBar';

export abstract class AppPage extends BasePage {
  readonly sideMenu: SideMenu;
  readonly topBar: TopBar;

  constructor(page: Page) {
    super(page);
    this.sideMenu = new SideMenu(page);
    this.topBar = new TopBar(page);
  }
}
```

La herencia queda así:

```
BasePage (goto, expectLoaded)
 ├── LoginPage                    sin menú: hereda de BasePage
 └── AppPage (sideMenu, topBar)
      ├── DashboardPage           con menú: heredan de AppPage
      └── PimPage
```

**Cuándo crear un componente:** solo cuando algo se repite de verdad en dos o más pantallas. Si tu aplicación no tiene partes repetidas, no necesitas `AppPage` ni `components/`.

---

## 13. Paso 11: más páginas

Una página que no tiene nada propio todavía solo define su `path`:

```ts
// pages/DashboardPage.ts
import { AppPage } from './AppPage';

export class DashboardPage extends AppPage {
  protected readonly path = '/web/index.php/dashboard/index';
}
```

Cuando hay varias páginas, crea el archivo `pages/index.ts` para importarlas todas desde un solo lugar:

```ts
export { BasePage } from './BasePage';
export { AppPage } from './AppPage';
export { LoginPage } from './LoginPage';
export { DashboardPage } from './DashboardPage';
export { PimPage } from './PimPage';
```

Y actualiza el fixture para que use ese archivo y registre las páginas nuevas:

```ts
import { DashboardPage, LoginPage, PimPage } from '../pages';
```

Ahora los tests pueden combinar páginas y componentes:

```ts
await loginPage.login(users.admin);
await dashboardPage.expectLoaded();
await dashboardPage.sideMenu.navigateTo('PIM');
await pimPage.expectLoaded();
```

Todas las páginas de un mismo test comparten la misma pestaña del navegador; se cambia de objeto cuando cambia la pantalla.

---

## 14. Paso 12: scripts de ejecución

En `package.json`:

```json
"scripts": {
  "test": "playwright test",
  "test:chromium": "playwright test --project=chromium",
  "test:headed": "playwright test --headed --project=chromium",
  "test:ui": "playwright test --ui",
  "report": "playwright show-report"
}
```

Se ejecutan con `npm run test:headed`, `npm run report`, etc.

---

## 15. Cómo elegir un buen locator

Usa el primero de esta lista que funcione. Los de arriba resisten mejor los cambios de diseño:

| Prioridad | Locator | Cuándo usarlo | Ejemplo |
|---|---|---|---|
| 1 | `getByRole` | Botones, enlaces, encabezados, menús | `getByRole('button', { name: 'Login' })` |
| 2 | `getByLabel` | Campos de formulario con etiqueta | `getByLabel('Correo')` |
| 3 | `getByPlaceholder` | Campos con texto de ayuda | `getByPlaceholder('Username')` |
| 4 | `getByText` | Textos que no son interactivos | `getByText('Bienvenido')` |
| 5 | `getByTestId` | El HTML tiene `data-testid` | `getByTestId('submit')` |
| 6 | `locator('css')` | Último recurso | `locator('.oxd-userdropdown-tab')` |

Técnicas útiles:

- **Encadenar** para buscar dentro de una zona: `this.root.getByRole('link', { name: 'PIM' })`.
- **Filtrar** una lista: `page.getByRole('row').filter({ hasText: 'Juan' })`.
- **`exact: true`** cuando un texto está contenido en otro.

Evita selectores basados en la posición (`nth(3)`) o en rutas largas de CSS/XPath: se rompen con cualquier cambio.

---

## 16. Reglas del patrón POM

1. **Una clase por pantalla** y un archivo por clase.
2. **Los tests no contienen selectores.** Si necesitas uno, agrégalo al Page Object.
3. **Los métodos se nombran por lo que hace el usuario** (`login`, `addEmployee`), no por el detalle técnico (`clickBotonAzul`).
4. **Lo repetido sube de nivel:** a `BasePage` si es de todas las páginas, a un componente si es un trozo de pantalla.
5. **No uses `waitForTimeout`.** Las acciones y los `expect` ya esperan solos.
6. **Los datos van en `data/`**, no escritos dentro de los tests.
7. **Cada test debe poder ejecutarse solo**, sin depender de que otro corra antes.
8. **Verificaciones:** en este proyecto, las que se repiten viven en el Page Object (`expectLoaded`, `expectError`) y las propias de un caso se escriben en el test con `expect`. Lo importante es mantener el mismo criterio en todo el proyecto.

---

## 17. Receta: agregar una página nueva

Ejemplo: agregar la pantalla **Admin**.

**1. Crear la clase** `pages/AdminPage.ts`:

```ts
import type { Locator, Page } from '@playwright/test';
import { AppPage } from './AppPage';

export class AdminPage extends AppPage {
  protected readonly path = '/web/index.php/admin/viewSystemUsers';

  readonly addButton: Locator;

  constructor(page: Page) {
    super(page);
    this.addButton = page.getByRole('button', { name: 'Add' });
  }
}
```

**2. Exportarla** en `pages/index.ts`:

```ts
export { AdminPage } from './AdminPage';
```

**3. Registrarla** en `fixtures/pages.fixture.ts` (en el tipo y en el `extend`):

```ts
type PageFixtures = {
  // ...
  adminPage: AdminPage;
};

adminPage: async ({ page }, use) => {
  await use(new AdminPage(page));
},
```

**4. Usarla** en un test:

```ts
test('abre el módulo Admin', async ({ dashboardPage, adminPage }) => {
  await dashboardPage.sideMenu.navigateTo('Admin');
  await adminPage.expectLoaded();
});
```

Son siempre los mismos cuatro pasos: **clase → index → fixture → test**.

---

## 18. Comandos útiles

| Comando | Qué hace |
|---|---|
| `npx playwright test` | Ejecuta todos los tests en todos los navegadores |
| `npx playwright test login` | Solo los archivos cuyo nombre contiene "login" |
| `npx playwright test --project=chromium` | Solo en Chromium |
| `npx playwright test --headed` | Mostrando el navegador |
| `npx playwright test --ui` | Modo interactivo: ejecutar y ver paso a paso |
| `npx playwright test --debug` | Depurador: avanza línea por línea |
| `npx playwright test -g "cierra sesión"` | Solo los tests cuyo título coincide |
| `npx playwright show-report` | Abre el último reporte HTML |
| `npx playwright codegen <url>` | Graba acciones y sugiere locators |

Dentro del código, `test.only(...)` ejecuta solo ese test y `test.skip(...)` lo omite. Recuerda quitar el `only` al terminar.

---

## 19. Errores frecuentes

| Síntoma | Causa | Solución |
|---|---|---|
| El test no reconoce `loginPage` | Importaste `test` de `@playwright/test` | Impórtalo de `../fixtures/pages.fixture` |
| Una acción "no hace nada" o el test termina antes de tiempo | Falta un `await` | Pon `await` en toda acción y todo `expect` de Playwright |
| `strict mode violation` | El locator encontró más de un elemento | Hazlo más específico: encadena, filtra o usa `exact: true` |
| `Timeout ... waiting for locator` | El locator no encuentra nada | Revisa el selector con `codegen` o el modo `--ui` |
| Error al usar `this` en el constructor | Falta `super(page)` o no es la primera línea | Llama a `super(page)` al inicio del constructor |
| La página abre una URL equivocada | El `baseURL` incluye una ruta | Deja solo el dominio en `baseURL` y la ruta en `path` |
| El fixture nuevo no existe | No lo registraste | Agrégalo al tipo `PageFixtures` y al `extend` |
| Fallos intermitentes por tiempo | El sitio de práctica es lento y compartido | Vuelve a ejecutar; no es un error de tu código |

Cuando un test falla, abre el reporte (`npx playwright show-report`): muestra el paso exacto, el error y una captura.

---

## 20. Ejercicios

En orden de dificultad. Hazlos sobre este mismo proyecto:

1. **Nuevo test con lo que ya existe.** En `navigation.spec.ts`, verifica que el botón `searchButton` de PIM sea visible.
2. **Nueva página.** Crea `AdminPage` siguiendo la receta del punto 17 y un test que llegue a ella desde el menú lateral.
3. **Nuevo locator y acción.** En `LoginPage`, agrega el enlace "Forgot your password?" y un método `openForgotPassword()`. Verifica que cambie la URL.
4. **Nuevo componente.** En `SideMenu`, agrega el campo de búsqueda del menú y un método `search(texto)`. Prueba que al buscar "PIM" quede una sola opción.
5. **Formulario completo.** Crea `AddEmployeePage` (se abre con el botón Add de PIM) con un método `addEmployee(nombre, apellido)` y un test que cree un empleado.
6. **Fixture avanzado.** Crea un fixture `loggedInPage` que haga el login por ti, para no repetirlo en cada `beforeEach`.
7. **Proyecto desde cero.** Repite todo el manual, sin copiar, con otro sitio de práctica: `https://www.saucedemo.com` (usuario `standard_user`, clave `secret_sauce`). Pantallas sugeridas: login, inventario y carrito.

El ejercicio 7 es la prueba real: si logras hacerlo solo, ya dominas el proceso.

---

## 21. Glosario

| Término | Significado |
|---|---|
| **POM** | Page Object Model: una clase por pantalla |
| **Page Object** | Clase que representa una pantalla (locators + acciones) |
| **Componente** | Clase que representa un trozo de pantalla que se repite |
| **Locator** | Descripción de cómo encontrar un elemento |
| **Fixture** | Recurso que Playwright prepara y entrega al test |
| **Spec** | Archivo de tests (`*.spec.ts`) |
| **Aserción** | Comprobación con `expect` |
| **baseURL** | Dirección base de la aplicación, definida en el config |
| **Headed / headless** | Con el navegador visible / sin mostrarlo |
| **Proyecto** (en el config) | Un navegador o dispositivo donde corren los tests |
| **Traza** | Grabación paso a paso de un test para analizar fallos |
| **`async` / `await`** | Forma de esperar acciones que tardan |
| **`extends`** | Herencia: una clase recibe lo que tiene otra |
| **`abstract`** | Clase o propiedad que solo existe para ser heredada |

---

### Resumen del proceso en una línea

**Instalar → explorar la aplicación → configurar `baseURL` → datos → `BasePage` → primera página → fixture → primer test → componentes → más páginas.**

Documentación oficial: https://playwright.dev/docs/intro
